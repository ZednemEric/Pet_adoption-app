import React from "react";

const ApplicationInfo = () => {
  return (
    <div></div>
  );
};

export default ApplicationInfo;
